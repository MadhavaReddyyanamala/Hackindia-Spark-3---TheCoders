from flask import Flask, render_template, request
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split

app = Flask(__name__)

# Load the data
df = pd.read_csv('W:/ML/car price prediction/car data.csv')

# Preprocessing
df.replace({'Fuel_Type': {'Petrol': 0, 'Diesel': 1, 'CNG': 2}}, inplace=True)
df.replace({'Seller_Type': {'Dealer': 0, 'Individual': 1}}, inplace=True)
df.replace({'Transmission': {'Manual': 0, 'Automatic': 1}}, inplace=True)

X = df[['Year', 'Present_Price', 'Kms_Driven', 'Fuel_Type', 'Seller_Type', 'Transmission', 'Owner']]
Y = df['Selling_Price']

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.1, random_state=2)

# Model
model = RandomForestRegressor()
model.fit(X_train, Y_train)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Retrieve the form data
    year = int(request.form['year'])
    present_price = float(request.form['present_price'])
    kms_driven = int(request.form['kms_driven'])
    fuel_type = int(request.form['fuel_type'])
    seller_type = int(request.form['seller_type'])
    transmission = int(request.form['transmission'])
    owner = int(request.form['owner'])

    # Create a DataFrame for prediction
    input_data = pd.DataFrame([[year, present_price, kms_driven, fuel_type, seller_type, transmission, owner]],
                              columns=['Year', 'Present_Price', 'Kms_Driven', 'Fuel_Type', 'Seller_Type', 'Transmission', 'Owner'])

    predicted_price = model.predict(input_data)[0]

    # Pass the user input and the prediction to the template
    return render_template('index.html', 
                           prediction_text=f'The predicted selling price of the car is: {predicted_price:.2f} lakhs',
                           year=year,
                           present_price=present_price,
                           kms_driven=kms_driven,
                           fuel_type=fuel_type,
                           seller_type=seller_type,
                           transmission=transmission,
                           owner=owner)

if __name__ == "__main__":
    app.run(debug=True)
